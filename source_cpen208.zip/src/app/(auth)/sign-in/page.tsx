import SignInForm from "@/components/form/SignInForm";

const page = () => {
  return(
    <div className="w-full">
      <SignInForm />
    </div>
  );


};
export default page;