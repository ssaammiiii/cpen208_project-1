import SignUpForm from "@/components/form/SignUpForm";

const page = () => {
  return(
    <div className="w-full">
      <SignUpForm />
    </div>
  );


};
export default page;