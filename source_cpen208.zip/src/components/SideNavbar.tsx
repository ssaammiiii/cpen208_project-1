import styles from './nav.module.css'
import { Button } from './ui/button';
const SideNavbar = () =>{
    return (
    
        
        <div className="fixed top-11 left-0 w-40 bg-zinc-200 h-screen">
           <div className={styles.nav}>
             
             <button className={styles.btn}>Profile</button>
             <button className={styles.btn}>Announcements</button>
             <button className={styles.btn}>Gradebook</button>
             <button className={styles.btn}>Tools</button>
             <button className={styles.btn}>Resources</button>
             <button className={styles.btn}>Quizes</button>
             
           </div>
            <div className={styles.nav}> 
           
            </div>
            </div>


    
        
        
    )
}

export default SideNavbar;